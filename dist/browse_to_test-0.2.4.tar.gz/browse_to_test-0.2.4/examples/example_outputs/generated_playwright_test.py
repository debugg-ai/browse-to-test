# Generated test script using browse-to-test
# Framework: playwright
# Language: typescript
# This script was automatically generated from browser automation data
import { test, expect } from '@playwright/test';
import { Page } from '@playwright/test';

test('login test', async ({ page }: { page: Page }) => {
    await page.goto('https://example.com');
    await page.fill('input[name='username']', '<secret>username</secret>');
    await page.fill('input[name='password']', '<secret>password</secret>');
    await page.click('button[type='submit']');
    // Unsupported action: done
});